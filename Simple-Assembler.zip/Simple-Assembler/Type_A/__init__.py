from .add import add
from .mul import mul
from .sub import sub
from .XOR import XOR
from .OR import OR
from .AND import AND
from .div import div
from .Compare import Compare
from .Invert import Invert
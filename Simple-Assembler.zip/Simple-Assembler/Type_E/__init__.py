from .je import je
from .jgt import jgt
from .jlt import jlt
from .jmp import jmp